"""

"""
# Python libraries
import sys
import numpy as np

# For visualization
from vis import vis_3d


def main():
    # From https://arxiv.org/pdf/2506.07230
    n_voxels = (200, 200, 200)
    spacing = (2.5, 2.5, 2.5)  # mm

    vol = np.fromfile(sys.path[0] + '/nema_iq_sc_f18_it10.img', dtype=np.float32)
    vol = np.reshape(vol, n_voxels, order='F')

    vis_3d(vol, spacing=spacing)

    return 0


if __name__ == "__main__":
    main()
